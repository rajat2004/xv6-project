#include "user.h"
#include "types.h"
#include "stat.h"

int main() {
    while(1) {}
    exit();
}