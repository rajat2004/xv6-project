#include "user.h"
#include "types.h"
#include "stat.h"

int main() {
  int i;
  for(i=0;i<100;i++)
  {
    printf(1,"%d\n",i);
  }
    topps();
    exit();
}
